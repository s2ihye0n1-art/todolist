# Mindful Todo Pro

React + Vite + Tailwind + Firebase 구조

기능:
- 가용 시간 예산
- Brain Dump
- 실제/예상 시간 분석
- 주간 통계
- Firebase 연동 준비
- GitHub Pages 배포 준비
