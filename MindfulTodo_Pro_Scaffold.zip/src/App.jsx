
export default function App(){
 return (
  <div className='p-8'>
   <h1 className='text-3xl font-bold'>Mindful Todo Pro</h1>
   <p>Production-ready scaffold</p>
  </div>
 )
}
